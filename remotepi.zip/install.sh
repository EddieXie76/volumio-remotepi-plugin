#!/bin/bash

#required to end the plugin install
echo "plugininstallend"
