#!/bin/bash

echo "Done"
echo "pluginuninstallend"
